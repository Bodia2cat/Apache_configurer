import os
from tkinter import *
repo = input("Where is this folder?")
os.system("""
sudo apt install apache2
sudo apt install git
git clone https://github.com/Bodia2cat/myprogblog_remaster
""")
os.system("sudo cp " + repo + "/myprogblog_remaster/murca.com.zip  /var/www/html/repo.zip")
os.system("cd /var/www/html && ls && sudo unzip /var/www/html/repo.zip")
os.system("sudo service apache2 restart")
os.system("clear")
print("[+] Done")
