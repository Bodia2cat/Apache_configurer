answer = confirm("Do you have android device? ")
if (answer == true) {
	alert("This site not for android, im sorry....");
	window.location = "https://google.com"
}
alert("Its my first all index site, so ENJOY baby.......");
